//function for displaying values
function dis(val)
{
document.getElementById("values").value+=val
 }
//function for evaluation
function solve()
{
let x = document.getElementById("values").value
let y = eval(x)
document.getElementById("values").value = y
}
//function for clearing the display
function clr()
{
document.getElementById("values").value = ""
}